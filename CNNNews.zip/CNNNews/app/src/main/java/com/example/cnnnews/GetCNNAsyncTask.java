package com.example.cnnnews;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ProgressBar;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Sandeep on 2/13/2017.
 */

public class GetCNNAsyncTask extends AsyncTask<String, Void, ArrayList<Cnn>> {
    MainActivity activity;

    public GetCNNAsyncTask(MainActivity activity) {
        this.activity = activity;
    }

    @Override
    protected void onPreExecute() {
        ProgressBar pb= (ProgressBar) activity.findViewById(R.id.progressBar);
        pb.setVisibility(View.VISIBLE);
        ImageButton f= (ImageButton) activity.findViewById(R.id.first_button);
        f.setVisibility(View.INVISIBLE);
        ImageButton p= (ImageButton) activity.findViewById(R.id.previous_button);
        p.setVisibility(View.INVISIBLE);
        ImageButton n= (ImageButton) activity.findViewById(R.id.next_button);
        n.setVisibility(View.INVISIBLE);
        ImageButton l= (ImageButton) activity.findViewById(R.id.last_button);
        l.setVisibility(View.INVISIBLE);
        Button fnsh= (Button) activity.findViewById(R.id.finish_button);
        fnsh.setVisibility(View.INVISIBLE);



        super.onPreExecute();
    }


    @Override
    protected ArrayList<Cnn> doInBackground(String... params) {
        try {
            URL url= new URL(params[0]);
            HttpURLConnection connection= (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.connect();
            int statusCode= connection.getResponseCode();
            if(statusCode == HttpURLConnection.HTTP_OK){
                InputStream inputStream= connection.getInputStream();
                return CnnUtil.parseNews(inputStream);

            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }  catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        return null;


    }


    @Override
    protected void onPostExecute(ArrayList<Cnn> cnns) {
        ProgressBar pb= (ProgressBar) activity.findViewById(R.id.progressBar);
        pb.setVisibility(View.INVISIBLE);
        ImageButton f= (ImageButton) activity.findViewById(R.id.first_button);
        f.setVisibility(View.VISIBLE);
        ImageButton p= (ImageButton) activity.findViewById(R.id.previous_button);
        p.setVisibility(View.VISIBLE);
        ImageButton n= (ImageButton) activity.findViewById(R.id.next_button);
        n.setVisibility(View.VISIBLE);
        ImageButton l= (ImageButton) activity.findViewById(R.id.last_button);
        l.setVisibility(View.VISIBLE);
        Button fnsh= (Button) activity.findViewById(R.id.finish_button);
        fnsh.setVisibility(View.VISIBLE);




        activity.onGetNews(cnns);
        super.onPostExecute(cnns);
    }

    static public  interface IData{
        public void onGetNews(ArrayList<Cnn> al);
    }

}
