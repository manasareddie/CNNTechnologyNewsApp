package com.example.cnnnews;

import android.util.Log;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * Created by Sandeep on 2/13/2017.
 */

public class CnnUtil  {



    static ArrayList<Cnn> parseNews(InputStream in) throws XmlPullParserException, IOException {
        XmlPullParser parser= XmlPullParserFactory.newInstance().newPullParser();
        parser.setInput(in,"UTF-8");
        Cnn cnn=null;
        ArrayList<Cnn> cnnArrayListList= new ArrayList<>();
        int event=parser.getEventType();

        while(event != XmlPullParser.END_DOCUMENT)
        {
            Log.d("TAGNAME",parser.getName()+"");
            switch (event)
            {
                case  XmlPullParser.START_TAG:
                    if(parser.getName().equals("item")) {
                            cnn = new Cnn();
                        }
                    if(cnn!=null) {
                        if (parser.getName().equals("title")) {
                            cnn.setTitle(parser.nextText().trim());
                        }
                    }
                    if(cnn!=null) {
                        if (parser.getName().equals("pubDate")) {

                            cnn.setPubdate(parser.nextText().trim());
                        }
                    }
                    if(cnn!=null) {
                        if (parser.getName().equals("description"))

                            cnn.setDesc(parser.nextText().trim());
                    }
                    if(cnn!=null)
                    {

                            if (parser.getName().equals("media:content")) {

                                //parser.getAttributeValue("

                                if (parser.getAttributeValue(null, "width") == parser.getAttributeValue(null, "height"))
                                {
                                    
                                    cnn.setLink(parser.getAttributeValue(null, "url"));
                                }
                            }

                    }

                    break;
                case XmlPullParser.END_TAG:
                    if(parser.getName().equals("item"))
                    cnnArrayListList.add(cnn);
                default:
                    break;
            }
            event= parser.next();
        }

        return  cnnArrayListList;

    }
}
